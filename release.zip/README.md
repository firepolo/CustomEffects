# Installation
- Unzip archive

- Copy the folder "custom-effects" in your ".../obs-studio/data/obs-plugins/--HERE--"

## Now for x86 system (32bit):
- Copy the file "bin/x86/custom-effects.dll" in ".../obs-studio/obs-plugins/32bit/--HERE--"

## Now for x64 system (64bit):
- Copy the file "bin/x64/custom-effects.dll" in ".../obs-studio/obs-plugins/64bit/--HERE--"

# Usage
- Create own file ".effect" and copy their in ".../obs-studio/data/obs-plugins/custom-effects/--HERE--"

## Important
- Leave the file "default.effect" in data of plugin